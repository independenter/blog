# Ukey 工具

智能密码钥匙（Ukey / USB Key）的完整实现与配套工具，按 **GM/T 0016-2012《智能密码钥匙密码应用接口规范》** 与
**GM/T 0017-2012《智能密码钥匙密码应用接口数据格式规范》** 开发，包含：

| 组成 | 说明 |
|---|---|
| **软 Ukey** (`libukeysoft`) | 一个用文件目录模拟出来的智能密码钥匙，本身就是一个 **SKF 库**（导出 `SKF_*`），私钥不出"令牌" |
| **SKF 接入层** (`ukeycore`) | `dlopen` 加载 SKF 动态库 —— **厂商硬件库、软库、以及 GmSSL 自带的 GM/T 0016 实现走同一条代码路径** |
| **命令行工具** (`ukeyctl`) | 设备/应用/容器/PIN/密钥/证书/密码服务/文件/小 CA/安全通道全部可命令行操作 |
| **Qt6 图形界面** (`UkeyGui`) | 八个页签的桌面应用：证书助手（统一入口：检测 UKey + 起停三通道服务）、设备与后端、应用与 PIN、密钥与证书、密码服务、文件管理、服务、日志 |
| **小 CA** (`ukeyca`) | 根证书、签发、吊销、CRL、可通信证书列表 |
| **加密服务** (`ukeyserv`) | SM2 密钥协商建立安全通道，握手之后**线路上不出现任何明文**；带证书注册与吊销检查 |
| **SDK** | `sdk/python` 与 `sdk/js` 两套 **纯语言实现**（零第三方依赖）的协商 + 封套 + 客户端 |

> 一句话：**用硬件 SKF 还是软算法，只由 `config/ukey.ini` 里一行 `backend` 决定**，上层（界面、命令行、服务、自测）代码完全不变；
> `skf_lib` 指哪个库都行 —— 厂商的 `.so`/`.dll`、本工程的软库，或者 **GmSSL**（它本身就导出 99 个 `SKF_*`，见第 4.2 节）。

---

## 1. 三十秒看懂架构

```
              UkeyGui (Qt6)   ukeyctl   ukeyserv   ukeyselftest / ukeyuitest
                     \           |         /               /
                      \          |        /              /
                    +------------v-------v-------------+
                    |  ukeycore  UkeyManager (高层封装) |   ← 只讲 SKF, 不认识 GmSSL
                    |  skf_types / SkfApi (dlopen)      |
                    +------+---------------+-----------+
                           |               |
              +------------v---+     +------v-------------+
              | 厂商硬件 SKF 库 |     | libukeysoft (软 Ukey)|  ← backend = skf / soft
              | (.so / .dll)   |     |  FileStore + Crypto  |
              +----------------+     +------+--------------+
                                            |
                                   +--------v---------+
                                   | ukeycrypto(GmSSL)|  SM2/SM3/SM4/HMAC
                                   +------------------+
     ukeyca (小 CA)  ── 签发/吊销/CRL ──┘
     sec (UKSEC-1 安全通道) ── 协商 + SM4-CBC + HMAC-SM3 ──┘
```

- `backend = skf` 时：`ukeycore` 用 `dlopen` 加载厂商提供的 SKF 库，按 GM/T 0016 的调用序列（`SKF_ConnectDev → SKF_OpenApplication → SKF_OpenContainer → SKF_*`）干活；
- `backend = soft` 时：加载的是本工程自己编译的 `libukeysoft`，它对上层而言**就是**一个"标准的 SKF 库"；
- 两条路径共用同一份接口声明（`src/core/SkfApi.h`），所以接入真硬件时不需要改任何业务代码。

## 2. 目录

```
Ukey/
├── CMakeLists.txt
├── README.md                  ← 本文
├── config/ukey.ini            ← "用硬件还是软算法" 就在这里
├── config/skf_vendors.conf    ← 原助手加载的 21 家厂商 SKF 库清单 (序号/中文名/目录/Win库/Linux库)
├── deps/UkeyDll/              ← 原助手依赖的 22 个厂商库目录 (145 个文件 ≈81 MB, 只读; 见 §4.2)
│   └── ../inventory.tsv       ← 逐文件的 PE/ELF 机器码 + 位宽 + 大小 + sha256 (由 §5.3 的脚本生成)
├── docs/                      ← 调研、设计、接口手册、服务与 SDK、界面截图、两份国标原文
├── scripts/                   ← probe.sh / build.sh / test.sh / run.sh (+ Windows 的 .ps1)
│                                另有 json-vs-crypto-bench.cpp —— 选型取证测速，不参与构建（见调研文档 §9）
│                                build_probe32.ps1 —— 用 MSVC vcvars32 编 32 位 ukeyprobe (厂商库全是 i386)
│                                build32.ps1 —— MinGW32 编整套 32 位 (ukeybridge 桥 + 自检 + 软库)，产物自带 i386 运行库（§4.2.1）
│                                rea_probe.sh + rea_report.cjs —— rea/Ghidra 静态取证（§5.2，Win 与 WSL 同一份）
│                                pe_argc.py —— 从 32 位 PE 的 ret imm16 数出参数**字节数**（§5.3）
│                                vendor_inventory.py —— 厂商库清单/位宽/sha256/同源重复（§5.3）
│                                sync_vendor_dlls.ps1|.sh —— 从原助手目录同步 deps/UkeyDll 并重建清单（§4.2）
│                                build_reimpl32.ps1 + parity_check.py + shell_vs_orig.ps1
│                                             —— 厂商 ABI 壳的构建 / 静态对表 / 真机对拍（§5.4）
│                                dwarf_params.py —— 从 .so 的 DWARF 里读回真参数名与类型（§5.4）
├── sdk/python/  sdk/js/       ← 两套零依赖客户端 SDK
├── third_party/README.md      ← 这些厂商头文件的口径: 是取证产物, 不参与构建、不进 78 项绑定表
├── third_party/zayk/          ← 从中安云科 zaykSkf.dll 提取的头文件 + 96 个导出符号存档
├── third_party/{flk,guoxin_three,zjca_blue}/  ← 另三家的导出符号清单 + rea 取证笔记（§5.2）
│   ├── flk/flkSkf.h           ← 弗兰科私有扩展声明 (14 个, 参数**字节数**来自机器码, §5.3)
│   ├── guoxin_three/guoxinSkf.h ← 国芯三级私有扩展声明 (12 个, 同上)
│   └── abi_sweep_21.md        ← 21 家 × 78 项标准接口的 ABI 交叉校验表（§5.3）
├── vendor_reimpl/             ← 四家厂商 ABI 壳的可编译源码（§5.4，Win 与 Linux 同一份源码）
│   ├── gen_forwards.py        ← 唯一生成器: 一张 config/skf_vendors.conf → 五份产物
│   ├── ReimplBackend.h        ← 后端接线: 首次调用按 UK_REIMPL_BACKEND 懒加载 + 逐符号转发
│   ├── build_linux.sh         ← Linux 侧编 .so，并把导出面与 .def 逐项自校验
│   ├── <厂商>/                ← 生成的 Forwards/Ext/Cdecl_gen.inc + exports_gen.def/.map + *Shell*.cpp
│   └── test/                  ← 假后端 + 探针 + run.sh/run.ps1（§5.4 证据 2）
├── src/
│   ├── core/     SKF 类型 + 加载器 + UkeyManager + 配置/日志/JSON/工具
│   ├── soft/     软 Ukey: FileStore + 密码原语 + COS + SKF_* 导出
│   ├── ca/       小 CA (根/签发/吊销/CRL)
│   ├── sec/      HTTP + UKSEC-1 安全通道
│   ├── service/  DeviceBroker + ukeyserv
│   ├── gui/      Qt6 界面 (每页一个 .cpp, 无自定义 Q_OBJECT)
│   ├── cli/      ukeyctl
│   └── log/      日志
└── tests/        selftest.cpp (288 项) / uitest.cpp (109 项真实点击) / skfprobe.cpp (多厂商真机探测)
                  / skf0based.cpp (0 基假厂商库夹具, 只用于测试)
```

## 3. 构建

依赖：`cmake` + `ninja`(或 `make`) + OpenSSL 开发包 + **GmSSL**；Qt6 只在需要界面时才要。
GmSSL 直接复用 `../algtool/third_party/gmssl/install`（若不存在请先 `bash ../algtool/scripts/build_gmssl.sh`）。

```bash
cd Ukey
./scripts/probe.sh          # 先看这台机器缺什么
./scripts/build.sh          # 产出 build/ (界面 + CLI + 服务 + 软 Ukey)
./scripts/test.sh           # 离线全量自检
./scripts/test.sh --online  # 再加: 起服务 + 两套 SDK 端到端联调
```

手工构建也一样：

```bash
cmake -S . -B build -G Ninja -DUKEY_BUILD_GUI=ON
ninja -C build
```

| CMake 选项 | 默认 | 作用 |
|---|---|---|
| `UKEY_BUILD_GUI` | `ON` | 编 `UkeyGui` 与 `ukeyuitest`；没有 Qt6 时跳过并在构建/打包输出里明确报"没有界面" |
| `UKEY_BUILD_SERVICE` | `ON` | 编 `ukeyserv` |
| `UKEY_BUILD_SOFT` | `ON` | 编软 Ukey `libukeysoft` |
| `UKEY_GMSSL_ROOT` | algtool 里的产物 | GmSSL 安装前缀（`include/` + `lib/`） |
| `UKEY_GMSSL_FEATURES` | 空（自动反查） | 手工指定 `libgmssl` 编译期的 `ENABLE_*` 宏，见第 3 节末注 |

Windows 用 `scripts/build.ps1` / `scripts/test.ps1`（参数与 `build.sh`/`test.sh` 一一对应），两者已在本机
Windows x64 + MSYS2 MinGW64 实测跑通：`build.ps1` 自动探 `cmake`/`ninja`/GmSSL/OpenSSL/Qt6 并生成
`build/*.exe`，`test.ps1` 串起 `ukeyselftest`/`ukeyuitest`/两套 SDK。
`build.sh` 同样会先探 Qt6 前缀（`--qt DIR` 可显式指定），探不到就明说"本次不出界面"，
而不是等打完包才发现 `dist` 里少了 `UkeyGui`。

Qt6 前缀的坑：MSYS2 的 Qt6 装在 `C:\msys64\mingw64`（`bin\qmake.exe` + `lib\cmake\Qt6`），
而 `C:\msys64\mingw64\share\qt6` 只是模块目录，拿它当前缀去探必然探不到。

32 位这一侧用 `scripts/build32.ps1`（Windows 硬件厂商库全是 i386，见 §4.2.1）：它拿 MSYS2 的
`mingw32` 工具链编整套 `build32\cmake\`（`ukeybridge.exe` / `ukeyctl.exe` / `ukeyserv.exe` /
`ukeyselftest.exe` / `soft\ukeysoft.dll`），**强制 `-DUKEY_BUILD_GUI=OFF`**（Qt6 没有 32 位 Windows 包），
末尾把 i386 运行库（`libgcc_s_dw2-1`/`libstdc++-6`/`libwinpthread-1`/`libgmssl.dll`）拷到 exe 同目录，
再用「PATH 只留 `C:\Windows\System32`」真起一次桥来自证。两个前置条件它都会先检查再动工：
`i686-w64-mingw32-g++.exe` 在不在（`pacman -S mingw-w64-i686-gcc`），以及 32 位 `libgmssl.dll` 的导出名
带不带 `@`（要 `-DCMAKE_SHARED_LINKER_FLAGS=-Wl,--kill-at`）。还有一条 PATH 顺序的坑写在脚本里：
`mingw32\bin` 必须排在 `mingw64\bin` 前面，否则 32 位 `g++` 会去加载 x64 的 `libstdc++-6.dll`，
而 CMake 只留下一句"编译器编不出简单程序"。

发布打包 `build.ps1 -Package`（或 `-PackageOnly` 复用现有产物）产出 `dist\Ukey-<ver>\` + 同名 zip：
四个 exe、`ukeysoft.dll`、GmSSL/OpenSSL/MinGW 运行库、`windeployqt` 的 Qt 运行库与插件、
`config/` `docs/` `sdk/`，以及 **`deps/UkeyDll/` 整目录 + `deps/inventory.tsv`** ——
`VendorCatalog` 的库根候选认的是"exe 同级 / 上一级的 `deps/UkeyDll`"，所以包内放了它，换一台机器解压即用厂商库
（约 81 MB，不要就 `-NoVendorDlls`）。**还带 `bridge32/`**（`ukeybridge.exe` + 它的 i386 运行库闭包，
不要就 `-NoBridge32`）—— 那 21 家厂商库全是 i386，64 位的 `UkeyGui` 去 `LoadLibrary` 只会拿到错误 193，
真正能用它们的是包内这个 32 位桥（`backend = remote`，§4.2.1）。桥摆在包的下一层是算过的：它靠
`exeDir/../config/ukey.ini` 找到包根的 `config/`，厂商库根则顺候选表落到包根那份 `deps/UkeyDll`
（开发机上编译期写死的工程路径排更前，所以那台机器上桥显示的是开发树那份 —— 这条区别写在 §4.2.1 最后一条）。**`windeployqt` 只管 Qt 自家的 dll**，mingw 版 Qt6 还依赖一批第三方
dll（`libicu*`/`libpcre2-16-0`/`libzstd`/`zlib1`/`libfreetype`/`libharfbuzz`/`libpng16-16`/`libmd4c`/
`libdouble-conversion`/`libb2-1`/`libbrotli*`/`libgio`…，只在 `mingw64\bin`），少一个的症状是
"双击没反应"而不是报错 —— 所以打包末尾还按 `objdump` 递归求依赖闭包补齐。
本机验证方式：把 `PATH` 削成只剩 `C:\Windows\System32` 后，包内五个 exe 都能跑（`UkeyGui --shot PREFIX`
出 8 页截图、`ukeyserv` 的 `/health` 正常、`ukeyselftest` 290/0、`ukeyctl` 直接出结果，
而 32 位的 `bridge32\ukeybridge.exe` 在那种 PATH 下也起得来 —— 逐条见 §4.2.1 最后一条）。
Windows 上尤其要注意 `UKEY_GMSSL_FEATURES`：构建机没有 `nm`/`dumpbin` 时无法反查 `libgmssl` 编译期的特性宏，
猜错会让 `X509_KEY` 两侧大小不一致而在小 CA 处直接崩 —— 这时显式传 `-GmsslFeatures ENABLE_SECP256R1;...`。

⚠ "跑了 `-Package` 却像没反应"不是慢：整包（含 `deps/UkeyDll` 与 `bridge32/`，未压 ~180 MB → zip 81 MB）
实测整条 `-PackageOnly` 连拷带压只要 **27 秒**，
真正常见的原因是脚本在中途被打断 —— `$ErrorActionPreference="Stop"` 下 PowerShell 5.1 会把**原生命令
写到 stderr 的每一行**当成 ErrorRecord，而 `windeployqt` 明知故犯地会报一条 "Translations will not be
available"（已经传了 `--no-translations` 也照报）。它一响，后面的依赖闭包 / config / 厂商库 / 32 位桥 / zip
五步全不执行，而你看到的还是**上一次那个旧 zip**（时间戳没变），于是体感就是"什么都没发生"。
现在这段临时降到 `Continue`、把 stderr 收进变量，并按"包内文件数是否真的增加"判定 `windeployqt` 干了活，
没增加就 `throw` 说清楚。排查口诀：先看 `dist\` 里 zip 的时间戳有没有变，再看包内有没有 `libQt6*.dll`。

## 4. 跑起来

### 4.1 软 Ukey（默认可跑，无需任何硬件）

```bash
./build/ukeyctl init --serial DEMO001     # 造一台软 Ukey (数据落在 data/softukey, 不碰 ~/.)
./build/ukeyctl info                      # 后端/设备/应用/容器/PIN/密钥/证书一览 (device 留空 = 枚举到的第一台)
./build/ukeyctl keygen                    # 容器内生成签名密钥对 (私钥不出令牌)
./build/ukeyctl keygen --enc              # 生成加密密钥对 (数字信封要用它)
SIG=$(./build/ukeyctl sign --text "hello" 2>/dev/null | grep -oE '[0-9a-f]{128}' | head -1)   # r‖s 各 32 字节
./build/ukeyctl verify --text "hello" --sig-hex "$SIG"            # → 验签通过
# sign 在 stdout 上会先打签名再打一行公钥, 所以脚本里取第 1 个 128 hex 就够 (head -1 不能省)
./build/ukeyctl ca-init                   # 起一个自己的小 CA (根私钥 data/ca/ca.key, 别入库)
./build/ukeyctl ca-issue --keygen --cn "张三" --type sign
                                          # 一步式: 令牌内生成密钥 → 小 CA 签发 → 证书写回容器
./build/ukeyctl ca-issue --pub "$(./build/ukeyctl pub 2>/dev/null | grep -oE '[0-9a-f]{128}' | head -1)" \
    --cn "张三" --type sign                                      # 或者手工给一把外部公钥签 (公钥用 pub / pub --enc 取)
./build/ukeyctl ca-list                   # 可通信证书台账: 序列号 / V=有效 R=吊销 / 类型 / 到期 / CN
./build/ukeyctl ca-revoke --serial 10df   # 吊销 + 重建 CRL (序列号取 ca-list 第一列)
```

密钥这件事有三条路：前两条私钥从头到尾不离开令牌，第三条是把你自己已有的私钥弄进去。

```bash
./build/ukeyctl container-create --container c2   # 建容器 = 顺手在令牌内生成签名+加密两对密钥 (--no-key 跳过)
./build/ukeyctl keygen                            # 再来一次就是**覆盖**: 旧公钥作废, 命令行会打印提醒,
                                                    # 服务端的 ukey.keygen 则必须显式带 overwrite
./build/ukeyctl key-import --in client.key        # 历史密钥迁移: 把外部 SM2 私钥封成 GM/T 0017
                                                    # ENVELOPEDKEYBLOB (用容器加密公钥 SM2 包一个一次性
                                                    # SM4 密钥, 再由它 CBCEncrypt 私钥) 导入并覆盖
```

`--in FILE` 收三种格式：SDK 存的密钥文件（JSON，含 `priv`/`pub`）、64 位 hex、裸 32 字节；
导入完会逐字节核对容器公钥是否等于 `priv·G`，不一致就直接报错，不会留下"密钥与公钥两张皮"的容器。

> **默认 PIN 是什么**：`admin_pin = user_pin = 12345678`（8 位），设备认证密钥 `dev_auth_key` 默认是
> hex `31323334353637383132333435363738`（即 ASCII `1234567812345678`，与 GmSSL 的出厂约定同源）。
> 这三个值来自 `config/ukey.ini` 的 `[ukey]` 段，`ukeyctl init` 建完设备会把它们打出来并提示改口：
> `ukeyctl pin-change --type admin --old 12345678 --new 新口令`。出厂值只用于开发/联调，生产必须换。

设备数据全部在 `data/softukey/devices/<设备名>/` 下 —— `device.ini`（设备档案 + 主密钥密文）、
`apps/<应用>/app.ini`（PIN 校验值与策略）、`apps/<应用>/containers/<容器>/container.ini`
（`sign_key_cipher` / `enc_key_cipher` 两把**口令派生密钥加密后的私钥**、证书、公钥）、
`apps/<应用>/files/`（GM/T 0016 6.5 的内部文件），
**整个目录拷走就等于把一把 Ukey 搬家**；`ukeyctl destroy --device NAME` 销毁。

**PIN 锁了怎么办**（三级出口，界面与命令行同口径）：

| 处境 | 做什么 | 代价 |
| --- | --- | --- |
| 只有用户 PIN 锁死 | PIN 页「解锁用户 PIN (需管理员 PIN)」／`ukeyctl pin-unblock --admin-pin A --new-user-pin N` | 无 |
| 管理员口令也忘了/也锁了 | PIN 页「强制重建应用」／`ukeyctl app-delete` + `app-create` —— 这两个接口属 GM/T 0016 §8.2.3 的**设备权限**，只认 `dev_auth_key`，不认 PIN | 该应用下的容器/密钥/证书 |
| 整台想回出厂 | 设备页「复位」／`ukeyctl reset --device NAME`（换主密钥，`SKF_Soft_ResetDevice`，仅软后端） | 全部应用 |

猜口令前先看清剩余次数：PIN 页顶部常驻 `PIN 状态: 用户 PIN: 剩余 6/6 (已改过出厂 PIN) …`，
每次校验失败立刻刷新；`ukeyctl pin-info --type user|admin` 是同一步的数据。软 Ukey 每把口令默认 6 次，
**猜完即锁**，管理员 PIN 锁死后第一行路也走不通，只剩重建。

### 4.2 接硬件 Ukey

```ini
; config/ukey.ini
[ukey]
backend   = skf
skf_lib   = /usr/lib/libskf.so        ; 或 C:\Windows\System32\wlbfbpi.dll
device    =                            ; 留空 = 枚举到的第一台
app_name  = ukeytest
container = sm2cont
admin_pin = 12345678
user_pin  = 12345678
```

改完这一行，界面/命令行/服务/自测全部照旧工作。厂商库若少实现某些函数，`UkeyManager` 会按能力位降级并在界面"设备"页
与 `ukeyctl info` 里明确写出"后端不提供什么"，而不是崩在半路。

**`skf_lib` 可以直接写厂商，不用抄绝对路径** —— 界面、命令行、服务、自测共用同一份解析口径（`src/core/VendorCatalog.cpp`）：

| 你写什么 | 解析成什么 |
| --- | --- |
| `12` / `zayk` / `中安云科` / `zaykSkf.dll` | 清单里那一家的当前库（Windows 取 `winName`，Linux 取与进程同位宽的 `.so`） |
| 完整路径 | 原样使用（认不出厂商代号时一律按路径处理，`libgmssl.so` 那条老用法不受影响） |

库根按"越靠近本工程越优先"依次找，第一个能命中至少一家的胜出：
`UKEY_SKF_ROOT` → 本工程 `deps/UkeyDll` → 产物同级 `deps/UkeyDll` → 原商业程序安装目录。
清单本身按 `UKEY_SKF_VENDORS` → exe 同级 `config/` → 工程 `config/` → `./config/` 找。

```powershell
# 把原助手依赖的 22 个厂商目录 / 145 个文件 (≈81 MB) 整目录搬进仓内并重建清单
.\scripts\sync_vendor_dlls.ps1                 ; # Windows: 默认源 D:\Program Files (x86)\UKey助手\deps\UkeyDll
.\scripts\sync_vendor_dlls.ps1 -DryRun         ; # 只报告将要新增/更新什么
bash scripts/sync_vendor_dlls.sh               # Linux 打包机: 只校验仓内 deps/UkeyDll 与清单是否一致
bash scripts/sync_vendor_dlls.sh -s <源目录>    # 也可从挂载盘同步
```

必须**整目录递归**而不是只挑主库：Windows 没有 RPATH，少一个从属文件就是
`ERROR_MOD_NOT_FOUND(126)` —— zayk 要同目录的 `CCWinDriver.dll`，haca 有 60 多个 `gdca_*.dll`
加 `gdca_device.ini`，`ht*`/`zjca_*` 还夹着 `*.dat` 预置数据。同步脚本只做"新增 + 覆盖更新"，从不删除。

界面上（设备页 → backend 选 `skf`）**"SKF 库"是一个可编辑下拉框**：21 家逐条列出，标签形如
`12  中安云科  zaykSkf.dll  —  32 位 i386 (本进程用不了)`，tooltip 给出厂商目录、命中的库根和已知偏差；
也可以直接手输路径或点"选择…"。位宽判断和装载是同一个口径（`VendorCatalog::archMismatch`），
所以**选完就在按钮上方写明这个进程用不用得了**，不用等装载器抛看不懂的 193。三家的坑在标签之外再记一遍：

- `guoxin_three/SKF.dll` 只是门面，运行期还要 `LoadLibraryA("GM_SKF.dll")`，本机没有那份 → 加载报 126；
- 弗兰科（`flk_jklx`/`jklx`）能在失败处弹模态框，还按设备持有**跨进程命名互斥** —— 别把它同时加载进
  常驻服务（18080 / 61232）和界面进程去操作同一把钥匙；
- 21 家的 Windows 库**全是 PE32/i386**，64 位的 `UkeyGui`/`ukeyserv` 只能拒载；体检走 32 位探针
  （`scripts/build_probe32.ps1` → `build32/ukeyprobe.exe`，见 §5.1），**日常使用走 32 位桥**（`backend = remote`，见 §4.2.1）。

**手上没有硬件也能验证这条分支**：`skf_lib` 指到本工程软库（`build/soft/libukeysoft.so`）就等于"用厂商库的路子
加载一个 SKF 库"；指到 **`libgmssl.so`** 更有说服力 —— GmSSL 自带一套 GM/T 0016 实现，导出 99 个 `SKF_*`，
和本工程接口表里的 78 个标准符号**逐个对得上**（`ukeyselftest` 第 6 组把这条钉住了），只是它不提供 `SKF_Soft_*`
扩展，所以 `softBackend()` 会正确判否、创建设备一类操作会被拒绝：

```bash
GM=$(ls "$PWD"/../algtool/third_party/gmssl/install/lib/libgmssl.so)
sed -e 's|^backend *=.*|backend = skf|' -e "s|^skf_lib *=.*|skf_lib = $GM|" \
    config/ukey.ini > /tmp/gm.ini
./build/ukeyctl --config /tmp/gm.ini info
# 已加载后端 skf 库 .../libgmssl.so  →  0x0a00000c SAR_NOTINITIALIZEERR: 未初始化   (干净报错, 不崩)
```

`[soft] store_dir` 的下发**按能力判定**（这个库导不导出 `SKF_Soft_SetStoreDir`），不按 `backend` 的名字判定 ——
所以 `backend = skf` + `skf_lib` 指向软库时，数据仍然落在你指定的目录，不会被静默写到别处。

### 4.2.1 backend = remote：让 32 位桥去加载厂商库（Windows 真机的正解）

上一条"全是 i386"意味着：64 位的 `UkeyGui` / `ukeyserv` / `ukeyctl` 无论怎么填 `skf_lib` 都装不动厂商库
（只会拿到 `ERROR_BAD_EXE_FORMAT(193)`），而 **Qt6 没有 32 位 Windows 发行版**，界面这一侧不能整体降位宽。
于是把"真正调 `SKF_*`"这件事搬进一个 32 位进程 `ukeybridge`，主程序只把每个高层方法变成一次本机 HTTP 调用：

```
64 位 UkeyGui / ukeyctl / ukeyserv            32 位 ukeybridge.exe            厂商 i386 dll
  UkeyManager(backend=remote) ──POST /rpc──▶ UkeyManager(backend=skf) ─LoadLibrary─▶ zaykSkf.dll
  {"m":"sign","a":{…}}        ◀──{"ok":true,"d":{…}}
```

- 传输层 `src/core/UkeyRpc.{h,cpp}`：一条回环 HTTP，`POST /rpc`，方法名 + JSON 参数，`Bytes` 一律十六进制。
  **代理做在 `UkeyManager` 这一层，不是 SKF ABI 那一层** —— 78 个入口各带结构体指针、双向 `ULONG` 长度和
  "缓冲区太小要重试"的语义，逐个搬运既容易错又错得静默；而高层方法的参数与结果本来就是 string / Bytes / uint32。
- 上层一行没改：界面、`ukeyctl`、服务、自测仍然只认 `UkeyManager` 那一套方法，`backend` 只是配置项。
- 桥只链 `ukeycore`（不碰 Qt，也不碰 GmSSL/OpenSSL），所以 32 位这一侧很薄，`--kill-at` 之外没有额外工程。
- **PIN 与密钥明文会经过这条管道**，所以桥只允许监听回环；填非回环地址它直接拒绝启动。要跨机请走 18080
  的安全通道（`SecChannel`），不是这条。

```powershell
.\scripts\build32.ps1        # MinGW32 整套 32 位（桥 + 自检 + 软库）；结尾自己证"只靠 exe 同目录的 dll 能起桥"
.\scripts\build.ps1          # x64 主程序（界面 / 服务 / 命令行）

# 32 位侧：先 --info 看清"这边装得动、看得见几台"，再真正监听
build32\cmake\ukeybridge.exe --backend skf --skf-lib zayk --info
build32\cmake\ukeybridge.exe --backend skf --skf-lib zayk --port 61233 --foreground

# 64 位侧：backend=remote，"SKF 库"这一栏填桥地址（留空 = config [bridge] 的 127.0.0.1:61233）
build\ukeyctl.exe --backend remote --skf-lib 127.0.0.1:61233 info

# 发布包里同一套（build.ps1 -Package 把桥连同它的 i386 运行库放进 bridge32\）
dist\Ukey-0.1.0\bridge32\ukeybridge.exe --backend skf --skf-lib zayk --port 61233 --foreground
dist\Ukey-0.1.0\ukeyctl.exe --backend remote info
```

界面上设备页的 backend 下拉多出 `remote`：选中后"SKF 库"那一栏的含义换成桥地址，旁边的**"探测桥"**按钮按一次
就显示"桥在不在 / 那边接的哪家库 / 接口面 / 已连哪台 / 枚举到几台"。它不重装本进程后端，所以不会把已连的应用踢掉
—— 分不清是插卡问题还是端口问题时先点它。`ukeyctl --backend remote --skf-lib host:port` 与服务侧同理。

本机的实测证据（2026-10-16，Windows x64 + 中安云科真机）：

- `scripts/build32.ps1` 全新构建 → **干净 PATH（只有 `C:\Windows\System32`）** 下 `ukeybridge --info` 起得来，
  软后端枚举到 3 台；`--backend skf --skf-lib zayk` 枚举到真机 `001805083B6045384C333837`（SinoCipher）。
  改这里之前的现象是 `0xC0000135`：64 位父进程拉 32 位桥时 PATH 上没有 i386 运行库，桥连一行字都没打出来。
- `build32\cmake\ukeyselftest.exe` **288 通过 / 0 失败**；x64 `ukeyselftest` **290 通过 / 0 失败** ——
  多的那 2 条是"位宽拒绝"，只有 64 位进程走得到，自测会把这句差异直接打出来。
- `ukeyuitest` **117 通过 / 0 失败**，设备页新钉住 5 条：下拉里有 `remote`、切过去"探测桥"立即可点、
  桥没起时给原因 + 起桥命令、64 位进程探活得着 32 位桥、探测结果显示那边的库/接口面/设备数。
- **整包也按同样的口径验过**（`dist\Ukey-0.1.0\`，81 MB，PATH 只留 `C:\Windows\System32`）：
  `bridge32\ukeybridge.exe --backend skf --skf-lib zayk --info` 起得来并枚举到那台真机（6 个 i386 运行库都在
  `bridge32\`，`soft\ukeysoft.dll` 的相对位置保住了）；换到**别的当前目录**用绝对路径再跑一次，配置文件解析成
  `bridge32\../config/ukey.ini`，也就是包根那份 `config/` —— 不用传 `--config`。随后包内的 64 位
  `ukeyctl.exe --backend remote info` 连上包内的桥，读到 `DEVINFO`（SinoCipher，空间 109952/131072）。
  一个要说清楚的区别：这台机器上 `VendorCatalog` 先命中编译期写死的工程目录，所以桥显示的是**开发树**那份
  `deps\UkeyDll`；换一台没放工程的机器，第一个存在的候选就是"exe 目录上一级的 `deps/UkeyDll`"（= 包根那份），
  想立刻指到别处用 `UKEY_SKF_ROOT`，它排第一，本机实测过。

⚠ **GmSSL 的 32 位库必须带 `-Wl,--kill-at` 重编**：i386 的 stdcall 导出默认带后缀（`SKF_EnumDev@12`），
而厂商库与本工程加载器都用不带后缀的名字（41 家里 0 个有 `@`）。缺这一步的现象是 32 位自检报"缺少必需的
SKF 入口"；`build32.ps1` 会先读 `bin\libgmssl.dll` 的导出表，带 `@` 就把重编命令整个打出来再退出。

### 4.3 图形界面

```bash
./build/UkeyGui                            # 用当前 DISPLAY / Wayland
QT_QPA_PLATFORM=offscreen ./build/UkeyGui --shot /tmp/shot   # 无头逐页截图
```

七页功能：**设备与后端**（选后端、装载库、创建/复位/销毁软 Ukey、连接、`DEVINFO` 能力位、设标签）、
**应用与 PIN**（枚举/创建/删除应用，PIN 校验/修改/解锁，PIN 策略与重试次数，容器管理）、
**密钥与证书**（签名/加密密钥对——**令牌内生成**、外部私钥**导入覆盖**、公钥导出、证书导入导出与小 CA 签发/吊销/CRL/台账表格）、
**密码服务**（随机数、SM3/SHA 摘要、带 ID 杂凑、签名验签、SM4 加解密、数字信封封装打开、双方 SM2 协商自检）、
**文件管理**（GM/T 0016 6.5 的内部文件读写删与权限位）、**服务**（起/停 ukeyserv、本机联调、证书台账、CRL）、**日志**。

界面截图见 [`docs/screens/`](docs/screens/)。

"应用与 PIN"页会先做只读探测：后端不认管理员 PIN（0 基厂商库，见 §7）时，解锁按钮与选中
"管理员 PIN"后的校验/修改/查询一律置灰，原因写在按钮 tooltip 和状态行上，不用先点一次拿错误码。

### 4.4 加密服务 + 客户端

```bash
./build/ukeyserv --foreground                 # 默认 127.0.0.1:18080
./build/ukeyctl enroll   --cn "cli-user"      # ① 向 CA 领证 (只提交公钥 + 持有证明)
./build/ukeyctl sec-call --op ukey.info       # ② 双向证书校验 + SM2 协商 + 加密调用
./build/ukeyctl sec-demo                      # ③ 一键演示: 领证→握手→echo/签名/信封往返
```

握手之后一切业务报文都是 `iv || SM4-CBC 密文`，另附 HMAC-SM3 校验值与严格递增序号，
**明文只在两端内存里出现**；吊销证书后（`ukeyctl ca-revoke --serial S` + 重建 CRL）握手会被拒绝。

服务端证书只说明"它信这条链"，还得说明"我信哪条链" —— 所以客户端支持**固定（pin）本地信任的 CA 根**：
`ukeyctl` 按 `--ca-cert FILE` > `[service] ca_cert_pinned` > `<ca_dir>/cacert.pem` 的优先级取，
并在每次调用前打印钉了谁；SDK 用 `ca_cert_file=` / `caCertFile:`。钉住之后要求 `hello` 下发的根
与之**逐字节相同**，验链与验 CRL 也一律以本地这份为锚 —— 否则中间人可以自造一整套 CA 把所有校验变成自证。

协议细节与全部接口/op 清单见 [`docs/服务与SDK.md`](docs/服务与SDK.md)、[`docs/接口与服务参考.md`](docs/接口与服务参考.md)。

```python
# sdk/python
from ukey_sdk import UkeyClient
c = UkeyClient("127.0.0.1", 18080, key_file="client.key")
c.gen_key().save_key()
c.enroll("python-demo")            # 领证 (服务端 CA 签发)
c.handshake()                      # 校验服务端证书 + CRL + SM2 协商 + 密钥确认
print(c.call("ukey.info"))         # 加密调用
print(c.call("ukey.digest", {"data_hex": "616263"}))
```

```js
// sdk/js
const { UkeyClient } = require('./ukey-sdk.js');
const c = new UkeyClient({ host: '127.0.0.1', port: 18080, keyFile: 'client.json' });
await c.genKey(); await c.saveKey();
await c.enroll('node-demo'); await c.handshake();
console.log(await c.call('ukey.info'));
```

两套 SDK 都不依赖 gmssl / cryptography / node-forge 之类第三方库：SM3、SM4、HMAC-SM3、SM2 签验与密钥交换、
X.509/CRL 解析全部自己实现，因此可以放进任何内网环境。**两套实现互相做过逐字节的跨语言一致性比对**。

### 4.5 ukey 提供地址（flk UKey 助手 `/skf/oper`）

浏览器前端调 UKey 时打的是「ukey 提供地址」，线协议与 UKSEC-1 不是一套（参数字母序 → HMAC-SM3 大写 hex
→ SM4-CBC 全零 IV 补零 → base64）。CLI / GUI / JS SDK 共用同一个配置项 `[service] provider_url`：

```bash
./build/ukeyctl provider                                # 打印当前地址 (默认 http://127.0.0.1:61231/skf/oper)
./build/ukeyctl provider --set https://ukey.flksec.com:61231/skf/oper   # 改地址并写回 config/ukey.ini
./build/ukeyctl provider --probe                        # GET 该地址 host:port 的 /health 探活
node sdk/js/flk-client.js                               # 读同一个键, 跑通 GetVersion→Login→ECCSign→验签
```

GUI「服务」页的"服务监听"分组里有同一个输入框，启动服务时随 host/port 一起写回 ini。
方向是"从 Ukey 侧调出去"；把这条服务**起起来**（复刻文档站 85 + `/skf/oper` 61231 + 软 Ukey 后端）
在隔壁目录 `../UkeyService`。协议细节见 [`docs/服务与SDK.md`](docs/服务与SDK.md) 第 13 节。

## 5. 自检

| 入口 | 覆盖 | 本机结果 |
|---|---|---|
| `./build/ukeyselftest` | 国标 KAT + 软 Ukey/SKF 调用序列 + PIN/容器/证书/文件 + **密钥生命周期（令牌内生成 → 覆盖保护 → 封装导入 → 重签证书 → 服务端身份自愈）** + 小 CA + 信封防篡改 + 协商 + HTTP 端到端 + 固定 CA 根 + **后端切换（`backend=skf` 那条分支，含 0 基假厂商库夹具 `tests/skf0based.cpp`）** + **签名 DER 编解码（与 GmSSL 差分对照）** + **第三方收尾顺序** + **厂商证书 PEM 外壳归一化 (derOfCert)** | **290 通过 / 0 失败**（x64；32 位侧 288，差的 2 条是只有 64 位进程走得到的「位宽拒绝」，§4.2.1） |
| `./buildgui/ukeyuitest` | Qt 界面八个页签**真实点按钮**（offscreen 驱动，含首页起停三通道、PIN 剩余次数随错口令下降、**后端不认管理员 PIN 时按钮禁用与提示**） | **109 通过 / 0 失败** |
| `python3 sdk/python/selftest.py` | SM2/SM3/SM4/X.509/封套 + 在线联调与负向用例 + **令牌内密钥/一步式办证** | **230 通过 / 0 失败**（离线 156） |
| `node sdk/js/selftest.js` | 同上 + 与 Python 版跨语言一致性 | **288 通过 / 0 失败 / 3 跳过**（离线 208 + 4 跳过） |
| `./scripts/test.sh --online` | 上面全部串起来，另加 **GmSSL 双向互操作**（`scripts/gmssl-interop.sh`）和 **ukeyctl 密钥生命周期**（建容器→令牌内生成→封装导入覆盖→签验） | **13 项全过 / 0 失败 / 0 跳过** |

其中 `ukeyskf0based`（`build/soft/`，只随测试构建）是一家**0 基假厂商库**：它把调用原样转发给真软 Ukey 库，
只把管理员编号 `ADMIN_PIN=2` 判成 `SAR_USER_TYPE_INVALID` —— 中安云科那类库的真实行为（§7）。
"探测→提示→禁用按钮"这条分支靠它在没有硬件的机器上被断言；真机复现要消耗 PIN 试错次数，不能当回归测试。

负向用例是重点：改一 bit 密文、换 IV、撕掉 MAC、重放旧序号、把服务端公钥换成别人的、用被吊销的证书握手、
**中间人自造一整套 CA 与叶子证书** —— 全部被拒绝，且不吐出任何明文。

> 口径备注：两套 SDK 的自检在 `scripts/test.sh --online` 里带 `--no-revoke-test`（不去碰 `data/ca` 的吊销台账），
> 所以那边看到的是 python **228** 与 js **286 + 4 跳过**；上表记的是直接跑命令（不带该开关）的全量。

### 5.1 多厂商 SKF 库探测（`ukeyprobe`）

上面几套自检跑的都是**软 Ukey**。要接真硬件，先跑这个探针 —— 它只依赖 `ukeycore`（`SkfApi` + `Util`），
不碰 Qt/GmSSL，所以同一份源码也能在 32 位裸 `cl` 下编出来，这点是硬要求：

**`D:\Program Files (x86)\UKey助手` 那套原程序加载的 21 家厂商库，Windows 侧全是 i386。** 64 位进程
`LoadLibrary` 它们只会拿到 `GetLastError=193`。所以：

```powershell
.\scripts\build_probe32.ps1                       # MSVC vcvars32, 产物 build32\ukeyprobe.exe
.\build32\ukeyprobe.exe --list-vendors            # 读 config\skf_vendors.conf, 21 行清单
.\build32\ukeyprobe.exe --root "D:\Program Files (x86)\UKey助手\deps\UkeyDll" --vendor 12
.\build32\ukeyprobe.exe --lib build32\reimpl\zayk\zaykSkf.dll --backend deps\UkeyDll\zayk\zaykSkf.dll
```

选厂商有三种口径，互不冲突：`--vendor <下标>`（认清单）、`--root` + `--vendor`（拼出原厂库路径）、
`--lib <绝对路径>`（直接指任意一个 dll，厂商不在清单里也能测）。最后一条是 §5.4 的对拍入口：
`--lib` 给源码构建的壳、`--backend` 给原厂库（壳会把它设成 `UK_REIMPL_BACKEND` 再懒加载），
同一条链在"原厂"和"壳→原厂"两种接线下各跑一遍，输出逐行比。

`config/skf_vendors.conf` 是把原 `ukeytool.exe` 的 `.rdata` 里那 21 条相对路径与同名中文下拉项抠出来
整理的（`序号<TAB>中文名<TAB>目录<TAB>Windows库<TAB>Linux库`），原程序按顺序试探、把命中的**下标**写进
`ukey.conf` 锁定厂商，`--vendor` 的编号就是那个下标。

探针按代价从低到高排阶段，每一段都能单独失败而不影响后面读数：库位宽 → 加载 → 78 个标准符号覆盖率 →
`EnumDev/ConnectDev/GetDevInfo` → `GenRandom` → 应用 → **PIN 类型只读试探** → 逐个容器（公钥/证书）→
最后才轮到 `VerifyPIN`。

**PIN 只许点一次**：`--pin` 不给就整段 SKIP；给了也只调**恰好一次**，错了直接报剩余次数并停手，绝不重试。
真正的护栏是它前面那次 `GetPINInfo`（只读，不消耗重试）—— 剩余次数为 0 就 SKIP，宁可不测也不锁设备。
编号也不是猜的：探针用 `GetPINInfo` 把 **0..4** 逐个只读试探（0 是 0 基厂商的管理员/SO 槽，
只看 1..4 会把它漏掉 —— 见 §5.2），只把**该库真认的编号**交给 `VerifyPIN`；
自动选号时只用 `USER_PIN(=1)`，绝不拿用户口令去扣 0 号管理员槽。

中安云科（`--vendor 12`，`zaykSkf.dll`）真机实测结论，全部写进
[`third_party/zayk/zaykSkf.h`](third_party/zayk/zaykSkf.h) 的溯源块：

| 观测 | 结论 |
|---|---|
| 78 个标准符号 | **缺失 0**，`stdcall` 装饰名 `_SKF_Xxx@N` 的 N/4 与我们的实参个数逐个吻合 |
| 私有扩展 18 个 | `SKF_Login`/`SKF_ECCDecrypt`/SM9 全家等，头文件里只按"名字+实参个数"声明，不臆造语义 |
| `GetPINInfo` 编号 0..4 | **0 和 1 都认**：0 = 管理员/SO 槽（仍是出厂默认），1 = 用户槽（已改过）；2/3/4 一律 `SAR_USER_TYPE_INVALID`。静态取证（§5.2）给出原因 —— 库里是 `ulPINType != 0 && ulPINType != 1` 的 0 基判断（`ADMIN_TYPE=0`/`USER_TYPE=1`），而我们 `skf_types.h` 的 `ADMIN_PIN=2` 在它眼里非法 |
| `ExportCertificate` | 返回的是 **PEM 文本**（带 `-----BEGIN CERTIFICATE-----` 与 CRLF）而不是 GM/T 0016 写的 DER |
| `CAContainer` / `Container` | 前者类型 0、无密钥无证书；后者 ECC/SM2，签名公钥 + 两本 SM2-with-SM3 证书齐全 |
| `Digest(SM3)` | 与 OpenSSL 的 `dgst -sm3` 逐字节一致 |
| `ECCSignData` + `ECCVerify` | 库内自签自验通过 —— 反证 `skf_types.h` 的 blob 布局可以直接喂给厂商库 |

最后两条里那个 PEM 是真会咬人的：上层（`SmallCa::certPub`、安全通道、界面保存）一律按 DER 走，所以
`UkeyManager::exportCert` 出口统一过 `derOfCert()` 剥壳，`--dump-cert` 同时落"厂商原文"和"剥好的 DER"两份。

21 家全量巡扫（同一台机器，只插着中安云科）：**20 家加载与符号覆盖全绿**，无设备的厂商报空列表或
`SAR_DEVICE_REMOVED`，都按"这家没插钥匙"归为 SKIP；只有 `公安三所（吉大正元）` 的 `EnumDev` 直接报
`0x0a000001 SAR_FAIL`，那是它自己的中间件缺失，属于要单独追的真问题。

### 5.2 厂商库静态取证（rea + Ghidra，Windows 与 Linux/WSL 同一份脚本）

探针能问的只有"插着的这块钥匙怎么表现"；PIN 锁了、设备没插、别家的语义都问不到。
补这条缺口用**静态取证**：把厂商库反编译出来读，全程不碰硬件、不试 PIN。工具是
[`rea`](https://github.com/morluto/rea)（把 Ghidra 包成 CLI 的取证驱动），采集脚本
[`scripts/rea_probe.sh`](scripts/rea_probe.sh)，本地分类器 [`scripts/rea_report.cjs`](scripts/rea_report.cjs)，
结论落在 [`docs/调研-通用Ukey形态与实现.md`](docs/调研-通用Ukey形态与实现.md) §4.2 与
`third_party/<厂商>/rea_findings.md`。

```bash
# 一次性环境（两边同构，都用便携目录，不动系统 PATH）
npm install --global rea-agents          # 要求 Node >= 24.11
export GHIDRA_INSTALL_DIR=/d/Tools/ghidra_12.1.4_PUBLIC   # Linux/WSL: ~/tools/ghidra_12.1.4_PUBLIC
export JAVA_HOME=<JDK 21+>               # Ghidra 的硬要求

./scripts/rea_probe.sh "D:/Tools/rea-targets/zayk/zaykSkf.dll" zayk
#   -> .rea-evidence/zayk/{overview,symbols,strings}.json + report.md  (证据不入库)
node scripts/rea_report.cjs .rea-evidence/zayk --md .rea-evidence/zayk/report.md   # 只重跑分类
```

踩过的坑，按值钱的顺序记：

- **Windows 侧 Ghidra 支持是 P0 实验，会话是一次性的**：每条命令都重新导入 + 重做自动分析，
  实测一条 25s~4min（250KB 的 i386 DLL）。`--snapshot` 省不掉这笔，所以脚本只调 **3 次**引擎
  （总览 / 全量符号 / 全量字符串），分类规则留在本地 `rea_report.cjs` 里反复改。
- **别用 `rea` 命令外壳**：Windows 上 npm 生成的是 `rea.cmd`/`rea.ps1`，Git Bash 里 `command -v rea` 找不到；
  Linux 那个 sh 外壳又要求登录 shell 的 PATH。两边统一走 `node <npm-global>/rea-agents/scripts/rea.mjs`
  （脚本里是 `REA_RUN`，不给就按常见位置自动探测）。
- **`--format` 只对 `analyze`/`search` 有效**，`decompile --procedure=X --format=…` 会报 `Unknown flag`；
  默认 toon 输出里 `normalized_result:` 那段就是伪代码。
- **函数数别只看 Ghidra**：它把库内私有 `SKF_*` 也算进过程名（`libSKFAPI.so` 报 100 个，实际导出 96），
  又把与别的导出共用入口的符号合并掉（flk 的 `SKF_RSADecrypt` 在导出表里、rea 报 88）。
  权威口径是 `objdump -x`（PE）/ `readelf --dyn-syms`（ELF），四家的全量清单已经存成
  `third_party/<厂商>/*_exports.txt`。
- **挑没 strip 的 `.so` 能直接"读源码"**：海泰系 `libSKFAPI.so` 带 DWARF，反编译出来就是
  `src/SKF_PinManage.cpp:123` 这种真文件名、真函数名、结构体字段名 —— 这是四家里性价比最高的一份。
- 写串分类规则时别用 `-----` 这类模式：厂商日志行本身以一串 `-` 开头，会把所有行都匹配上。

### 5.3 厂商库清单与 ABI 交叉校验（两份纯标准库脚本，不加载库、不碰硬件）

§5.1 的探针要插钥匙、§5.2 的取证要跑 Ghidra，但有两件事既不花钱也不需要硬件就能钉死：
**库文件到底是谁、位数是多少**，以及**厂商导出的函数按我们的原型调用会不会栈失衡**。

```bash
python scripts/vendor_inventory.py --write   # 生成 deps/inventory.tsv (145 条: 类型+机器码/位宽/大小/sha256/架构)
python scripts/vendor_inventory.py --check   # 清单与目录是否一一对应 (本机: 145/145, 缺 0 多 0)
python scripts/vendor_inventory.py --conf config/skf_vendors.conf   # 21 行逐条核对库在不在 (本机 0 缺)
python scripts/vendor_inventory.py --dups    # sha256 相同的同源重复组

python scripts/pe_argc.py --selftest          # x86 长度解码器 18 条用例
python scripts/pe_argc.py --check src/core/skf_types.h build32/…    # 单个 dll 与标准原型逐个校准
python scripts/pe_argc.py --sweep              # 21 家全量 → third_party/abi_sweep_21.md
```

位宽口径与运行时同一个函数（`VendorCatalog::fileBitsOf()` 的 Python 版）：PE 读 `e_lfanew@0x3C` 再取
Machine，ELF 读 `EI_CLASS@4` + `e_machine@18`（大端包要按 `EI_DATA@5` 决定字节序）。所以清单里标 32 的库，
GUI 下拉框与装载器一定也判 32 并拒绝 —— 两边不会各说一套。

两条结论值得单独记：

- **"清单里两行"不等于"两块不同的库"**（`--dups` 实测 9 组）：`flk_jklx` 与 `jklx` 的
  `JKLX_UKEY_GMAPI.dll` 同体（`bcf8523c…`）；海泰家族 `ht`/`ht_red`/`zjca_blue`/`zjca_white`
  的 `GECSP*.dll` 四家同体（`0893ec8e…`），`ht` 的两份 `.so` 与 `zjca_blue/libSKFAPI.so` 也同体 ——
  `SKFAPI*.dll` 只是改名的壳；`tjca/UKeySC.dll` == `ydx/GMUKeySC.dll`；`njgl_bjca` 两个文件名同体。
  21 行清单背后其实只有 ~16 个引擎，接第二家"同族"库时别指望行为有差异。
- **78 项标准接口 × 21 家的参数**字节数**逐个对表，"不符"合计 0 处**（表在
  [`third_party/abi_sweep_21.md`](../third_party/abi_sweep_21.md)）：i386 的 `__stdcall` 由被调方清栈，
  函数尾 `ret 0xNN` 的 NN 就是调用方压栈的总字节数，与我们 `skf_types.h` 的原型对表即可 ——
  `SKF_EncryptInit` 的 `0x30 = 4 + 44` 顺手双向印证了 `BLOCKCIPHERPARAM` 是 44 字节。
  这意味着 `src/core/SkfApi.cpp` 那张 78 项绑定表对所有厂商都可以共用一份原型，不必逐家适配。
  **唯一的例外**是海泰家族：那 4 家各有 5 个标准入口（`SKF_VerifyPIN`/`ChangePIN`/`CloseApplication`/
  `CloseContainer`/`CloseHandle`）以**裸 `ret`** 收尾，即按 cdecl 编译，与 0016 的 `DEVAPI=__stdcall` 冲突；
  本机没有海泰硬件、未做真机验证，所以只在厂商注解里标出来 —— 真接海泰时若出现栈漂移先查这 5 个。
  ⚠ 私有扩展那一边还有 5 个同名现象（`SKF_RSADecrypt`/`ExtRSAPubKeyOperationEx`/
  `ExtRSAPriKeyOperationEx` 来自 DWARF，`SKF_WriteLicence`/`SKF_CheckAnKe` 来自反编译 ——
  后两个连 `ret imm` 都读不出字节数，只有函数体能说明它们**有参且是 cdecl**），
  所以 zjca_blue 的壳要交两个编译单元，例外合计 10 个（见 `third_party/decomp_findings.md` §6.4）。
  "读不出"的那些（海南CA 17 个、契约锁 32 个）是 `jmp [IAT]` 式转发桩，函数体在别的模块里，
  **读不出 ≠ 参数不符**，别把它当成不兼容的证据。

厂商私有扩展（`SKF_ECCDecrypt`、`SKF_LoadRA`、SM9 那批…）没有任何规范可依，参数个数只能这样从机器码里数。
已经落地的四份声明都按这个口径写：[`third_party/zayk/zaykSkf.h`](../third_party/zayk/zaykSkf.h)、
[`third_party/flk/flkSkf.h`](../third_party/flk/flkSkf.h)（14 个扩展）、
[`third_party/guoxin_three/guoxinSkf.h`](../third_party/guoxin_three/guoxinSkf.h)（12 个）、
[`third_party/zjca_blue/zjcaSkf.h`](../third_party/zjca_blue/zjcaSkf.h)（26 个扩展 + `EPS_*` 六个，
名字来自 DWARF、分支语义来自反编译）。
它们**不进** 78 项绑定表，只是取证产物；四家都验证过 `--check` 标准 78 项全吻合，四份文件
`g++ -fsyntax-only -std=c++17` 干净。同名扩展在不同家参数也不同 —— 例如
`SKF_ECCDecrypt` 在 flk 是 `0x10`（4 参）、在国芯三级是 `0x14`（5 参），所以别写一份跨厂商共用的扩展头。

### 5.4 厂商 ABI 壳：把四家库的接口面变成可编译源码（Windows + Linux 同一份）

§5.1~§5.3 都是"读厂商的二进制"。这一步反过来：**用源码把那四家的导出面重写一遍**，
产物放在 `vendor_reimpl/`，Windows 编成 `.dll`、Linux 编成 `.so`，两边源码完全共用。

先说清楚它复刻的是什么层次，否则会误解成"自己实现了一遍 SM2"：

- **不是重写密码算法**。壳里 78 个标准入口是**逐参数直通**的转发 —— 它把调用原样交给一个后端库，
  后端由环境变量 `UK_REIMPL_BACKEND` 指定，首次调用时才 `LoadLibrary`/`dlopen`（懒加载，链接期不依赖厂商库）。
  后端指向原厂 dll，壳就是"一层可见的透明壳"，可以原地替换原厂库去跑同一条链；
- **私有扩展按取证语义自己实现**：只有 zayk 那 18 个（`SKF_Login`、SM9 全家、`*_EX` 系列）是手写的，
  守卫顺序、空指针判断和返回码都按 §5.2 反编译读到的逻辑写，不转发。
  flk 的 14 个与国芯三级的 12 个是**逐参数取证过的**直通桩 —— 原型里每一格都有 `[编]` 出处
  （[`third_party/decomp_findings.md`](third_party/decomp_findings.md)：57 条私有扩展全部反编译成功，
  与 `pe_argc.py` 的字节数对账**零冲突**），所以生成器不再按字节数猜类型。
  zjca_blue 另外补了 13 条（§6）：DWARF 给了名字，反编译给出**分支语义**，两侧参数个数逐条吻合，
  其中 `EPS_*` 六个第一次写进头文件；同轮还坐实了 2 个"裸 ret 却有参"的 cdecl 入口
  （`SKF_WriteLicence` 4 参、`SKF_CheckAnKe` 1 参），这家的 cdecl 例外从 8 个变 10 个。
  剩下还写 `void*` 的只有三类，而且都是**有意留白**：flk 的三个未实现桩（机器码就是
  `mov eax,0x0a000003; ret imm`，体内一次形参都不读 → 参数表在这份 dll 里永远问不出来），
  zjca_blue 的 `SKF_ReadLicence`/`SKF_DeleteLicence`（函数体就一句 `return 0;`，五格/两格全不读，
  名字与语义都被作废，只剩栈槽数量是真的），以及"原样透传给运行期函数指针表"的位置
  （表槽不带符号名，定名必须再取一层证据）。
- **zjca_blue 要两个编译单元**：它的 104 个导出里 5 个标准名 + 5 个扩展名是 **cdecl**（§5.3 记的海泰家族
  例外；扩展那 5 个中 `SKF_WriteLicence`/`SKF_CheckAnKe` 是本轮反编译才坐实的，两者都是"裸 ret + 有参"），
  生成器给它们单开 `Cdecl_gen.inc` 和 `ZjcaShellCdecl.cpp`，同一次链接交出去，导出仍由同一张表决定。

一张清单生成全部输入，改名只改 `config/skf_vendors.conf`：

```bash
python vendor_reimpl/gen_forwards.py            # → 每家 5 份产物
python vendor_reimpl/gen_forwards.py --check    # 产物与清单是否一致 (20 份, 已一致)
```

产物是 `Forwards_gen.inc`（78 项标准直通）、`Ext_gen.inc`（扩展直通桩）、`Cdecl_gen.inc`、
`exports_gen.def`（Windows 导出表）、`exports_gen.map`（Linux version script）。
**导出名只由这张表决定，两边都不靠源码里的 `dllexport`**：MSVC 不允许在已声明的普通原型上再加
`dllexport`（C2375），而带标签的 version node 会给符号打上 `@@zaykSkf`，`.dynsym` 里的名字与原厂 dll
就再也逐字节对不上了 —— 所以 `.map` 用的是**匿名版本节点**，只筛可见性、不注版本。

构建与测试：

```powershell
python vendor_reimpl/gen_forwards.py
.\scripts\build_reimpl32.ps1                    # 默认 -Vendor all: 四家壳 → build32\reimpl\<vendor>\<与原厂同名>.dll
.\scripts\build_reimpl32.ps1 -Vendor zayk       # 只编一家时用这个
python scripts\parity_check.py                  # 证据 1: 与原厂逐个对导出名 + ret imm
```

Windows 侧的壳住在 `scripts/build_reimpl32.ps1`，Linux 侧住在 `vendor_reimpl/build_linux.sh` —— 两边
都是"不带参数就全量"。分开放是因为 Windows 这次构建必须走 vcvars32（32 位工具链，见下面第 1 个坑），
它和主工程的 `scripts/build.ps1`（x64）不是一回事，混在一个脚本里最容易编出加载不了的 64 位壳。

```bash
bash vendor_reimpl/build_linux.sh               # WSL/Linux → build_linux/reimpl/lib*.so + 导出面自校验
bash vendor_reimpl/test/run.sh                  # 证据 2 (Linux): 假后端验证转发机制
```

```powershell
powershell -File vendor_reimpl\test\run.ps1      # 证据 2 (Windows, 32 位)
powershell -File scripts\shell_vs_orig.ps1       # 证据 3: 真机同链对拍
```

三层证据各自钉死一件事，本机实测（Windows x64 + MSVC vcvars32，WSL Ubuntu-22.04 g++，插着中安云科）：

| 证据 | 钉死的问题 | 实测 |
|---|---|---|
| 1 `parity_check.py` | 壳有没有**自创或漏掉**接口 | 96/92/90/104 全部同名同调用约定同参数字节数，不符 0（`zjca_blue` 另有 14 个原厂侧 `jmp` 桩读不出、1 个已知厂商偏差 `SKF_Format`） |
| 2 `test/run.{sh,ps1}` | 转发**机制**对不对 | 假后端返回码原样透传、指针出参原样透传；后端缺席→`0x0A000001`、扩展没取证语义→`0x0A000003`，两种非成功码可区分、都不崩。四家 × 两平台全 PASS |
| 3 `shell_vs_orig.ps1` | 换进上层之后**看不看得出来** | `--lib 壳 --backend 原厂` 与 `--lib 原厂` 跑同一条无 PIN 链，逐行一致。zayk 真机 66 行、其余三家各 17 行（无钥匙，加载+78 项符号+扩展清单全对齐，设备段 SKIP）全 PASS |

对拍脚本里两处归一化是有原因的，别当成"糊过去了"：`== 后端库 ==` 那一段只属于壳这次实验的接线，
删掉并把多出的 PASS 数补回原库那侧；`SKF_GenRandom` 打出的那行十六进制**本来就该不同**（随机数），
整行换成 `<RANDOM>`，而它前后的返回码与字节数照旧逐字比。
**PIN 链坚决不进这个脚本**：同一条链要跑两遍，双倍消耗厂商设备的重试次数，一次成一次锁会被读成"功能不一致"。

四个必须记住的坑：

- **壳必须编成 32 位**（Windows 侧）。原厂库全是 PE32/i386，64 位进程加载只会得到 193；
  而且证据 1 靠的 `ret imm16` 是 i386 `__stdcall` 被调方清栈才有的东西，x64 上根本没有。
- **后端绝对路径要用 `LOAD_WITH_ALTERED_SEARCH_PATH`**。厂商库的兄弟依赖住在自己旁边
  （zayk 的 `CCWinDriver.dll`），普通 `LoadLibrary` 报 126。这与 `src/core/SkfApi.cpp` 加载原厂库时
  同一个决定，两处别各写一套。Linux 侧靠 `LD_LIBRARY_PATH`。
- **Linux 只有四家里的 zjca_blue 有 `.so`**。清单 21 家中仅 4 家随库附 Linux `.so`（`gen_forwards.py`
  的 `orig_lib()` 读那一列），所以另外三家的 `lib*.so` 是我们自己的源码产物，`build_linux.sh` 末尾
  拿 `nm -D` 与 `.def` 做 `comm` 双向 diff 就是为了让"导出面两边不漂移"这件事有机器凭据。
  zjca 的真参数名是从 `libSKFAPI.so` 的 DWARF 里读回来的（`scripts/dwarf_params.py` →
  `third_party/zjca_blue/prototypes_dwarf.tsv`），这是四家里唯一带调试信息的原厂二进制。
- **改头文件的参数*类型*不会断构建，只会在 Linux 少一个导出**。`extern "C"` 声明与壳里的定义类型
  对不上时 g++ 零诊断（本轮实测：`rc=0`、`nm` 里只有 mangled 的 `f(void*)`），Windows 的 `.def` 按
  未修饰名导出所以照旧 96/96 全绿，Linux 的 `.map` 按符号名配对，那一项被静默剔除。本轮补参数时
  `SKF_ECCSignData_EX` 的第 5 格就是这么丢的，抓它的是 `build_linux.sh` 的导出名对表，不是编译器 ——
  所以补完类型要**头文件与同名 `*Shell*.cpp` 一起改，两边都构建**（复现见
  [`third_party/decomp_findings.md`](third_party/decomp_findings.md) 末节）。

## 6. 设计要点（为什么这么写）

1. **接口一致性优先**：`skf_types.h` 里的结构体/常量按 GM/T 0016 原样定义（`DEVINFO`、`ECCKEYBLOB`、`FILEECCHEAD`、
   `SAR_*`、`SGD_*`），句柄是 `DEV→APP→CONTAINER` 三级，和真机一模一样。
2. **私钥不出令牌**：软 Ukey 的私钥以口令派生密钥加密后存盘，签名/解密/协商都在库内部完成；
   协商时临时私钥也留在令牌内（`SKF_GenerateAgreementDataWithKeyWithECC`），对外只给临时公钥。
3. **签名密钥 ≠ 加密密钥**：容器内是两对 SM2 密钥。数字信封必须封给**加密公钥**（界面/命令行/SDK 都做了提示），
   封错了对公钥令牌里解不开 —— 这是实际硬件的通行约束，也是最常见的接入口误。
4. **encrypt-then-MAC**：信封先验 SM4-CBC-MAC 再解密，MAC 覆盖 `iv || 密文`，所以换包/改 IV 都能检出。
5. **界面不写新的 Qt 类**：页面是自由函数 + 现成控件，因此整个 GUI 不需要 `moc`，
   也才能把界面页直接链进 `ukeyuitest` 用 `QPushButton::click()` 无头驱动。
6. **GmSSL ABI 陷阱已在构建里解决**：`CMakeLists.txt` 用符号表（POSIX 走 `nm`/`llvm-nm`，Windows 走 `dumpbin /exports`）
   反查 `libgmssl` 实际编译进的特性宏（`ENABLE_SECP256R1` 等）再对齐传给本工程的 `-DENABLE_xxx`；不对准时 `X509_KEY`
   这个 union 两侧大小不同，库内 `memset` 会直接写爆调用方栈。这一条是**实测过的**：只按 2 个宏编译时，
   `ukeyselftest` 正好崩在进入小 CA 的第一个 `X509_*` 调用上；反查得到全部 7 个宏后 228 项全过。
7. **信任锚必须是本地的**：校验服务端证书时，"信哪条链"不能由对方决定。客户端可固定本地 CA 根
   （逐字节比对 `hello` 下发的根 + 以本地根为锚验链验 CRL），没固定时按 TOFU 运行但会打 WARN 并在输出里明说。
8. **按能力而不是按名字分支**：`backend` 只是"去 dlopen 哪个文件"，真正的功能差异全部由"这个库导出没导出某个
   `SKF_*`"决定（`softBackend()` 判据是 `SKF_Soft_CreateDevice`，`[soft] store_dir` 下发判据是
   `SKF_Soft_SetStoreDir`）。所以 `backend = skf` + `skf_lib` 指向软库/GmSSL 这类非常规组合也能正确工作，
   不会出现"配置写了一份、数据落到另一份"。
9. **换密钥 = 换身份**：服务对外的握手身份（`server_pub` / `server_cert` / `server_sig`）用的就是容器里
   那把**签名密钥与签名槽证书**，不是另一套。所以 `ukey.keygen` / `ukey.key_import` / `ukey.cert_import`
   都必须让 broker 重新引导（`refreshIdentity()`，GUI 同进程场景走惰性的 `invalidateIdentity()`），
   否则就变成"新私钥 + 旧公旧证书"，客户端握手时逐字节比对证书公钥与 `server_pub` 就会直接报
   "服务端证书与 server_pub 不一致 (疑似中间人)"。
   `ensureIdentity()` 采纳容器证书前先比对证书公钥与当前公钥，不匹配就当没有 → 回到台账/重签/写回那条路。
10. **服务不拉重依赖**：曾评估过把 muduo（网络库）与 yyjson（JSON）作为子模块引入，结论是**都不引入** ——
    muduo 官方 README 写定只支持 Linux + 需要 Boost，与本工程要兼顾 Windows 直接冲突；自家 JSON 解析一条
    1.2KB 报文实测 1.7µs（≈ 700 MB/s），而一次 SM2 签名是 77µs ≈ **45 次整包解析** —— JSON 不在瓶颈上。
    muduo 值得学的工程做法（连接收发超时、并发上限）则补进了自研 `Http.cpp`：每连接 30 秒
    `SO_RCVTIMEO`/`SO_SNDTIMEO`，在飞连接超 64 个直接回 503。
    取证与实测数据见 [`docs/调研-通用Ukey形态与实现.md`](docs/调研-通用Ukey形态与实现.md) §9，
    测法可重现（`scripts/json-vs-crypto-bench.cpp`）。

## 7. 已知限制

- 软 Ukey 的口令保护是"文件目录模拟令牌"级别的强度，**不能等同于硬件的安全元件**；它是用来学习、测试、联调的。
- `GM/T 0017` 的部分冷门数据格式（RSA 密钥格式、扩展 ASN.1 应用）只做到能互通的最小程度；RSA 全系在软库里返回 `SAR_NOTSUPPORTYETERR`。
- 服务是 HTTP 而非 HTTPS：通道的机密性与完整性由 UKSEC-1（SM2 协商 + SM4-CBC + HMAC-SM3 + 序号防重放）自己保证，
  但**没有传输层证书**，也不做前向保密（协商的 `t` 含长期私钥）。生产部署若要对外网，请叠加 TLS 或在专网内使用。
- 纯语言 SDK（Python/Node）的 SM2 标量乘是朴素实现，**非常量时间**，不抗侧信道；性能比 C++/GmSSL 低 2~3 个数量级。
- X.509 解析只覆盖本服务用到的字段（SM2 曲线 + SM3withSM2 + 单级 CA + CRL 序列号），不是通用证书库。
- 不固定 CA 根时是 TOFU（第一次连接信对方下发的根）：为了不误伤既有部署，这种情况只打 WARN 不失败。
  跨机器使用时请把服务端的 `cacert.pem` 拷到本地并 `--ca-cert` / `ca_cert_pinned` / `ca_cert_file` 钉住。
- `scripts/build.ps1` / `test.ps1` 现在 Windows 侧跑过（`test.ps1` 补了 UTF-8 BOM，否则 Windows PowerShell 5.1
  会按 CP936 解码而直接语法报错）。两个已知的环境依赖项：**`ukeyuitest` 要 Qt 的 bin 在 `PATH` 上**
  （不然以 `0xC0000135 STATUS_DLL_NOT_FOUND` 退出，把 `C:\msys64\mingw64\bin` 与 Qt bin 加进去就是 86/0），
  以及 `node sdk/js/selftest.js` 的跨语言那一组要调 `python`：本机 `python` 解析到原生 CPython 时，
  它会把 node 管道过来的 UTF-8 JSON 按 GBK 读而 `JSONDecodeError`，**加 `PYTHONUTF8=1` 即可**。
  在线联调那一组以前在 Windows 上直接报"找不到 build/ukeyserv"，因为两套 SDK 的路径按 Linux 写的、
  而这里是 `ukeyserv.exe`／`ukeyctl.exe`；现在后缀自己跟着平台走，本机实测 js **288 通过 / 0 失败 / 3 跳过**、
  python **230 通过 / 0 失败**（与 Linux 侧同一口径）。
- **接 Windows 硬件厂商库必须有 32 位进程在场**：原助手那 21 家厂商的 `.dll` 全是 i386，64 位的 `ukeyctl`/`UkeyGui`
  加载只会得到 `GetLastError=193`。正解是 `backend = remote` + 32 位 `ukeybridge`（§4.2.1）；体检走 32 位 `ukeyprobe`（§5.1）。
  桥的 i386 运行库必须与 exe 同目录 —— `build32.ps1` 会把它们拷齐，并用「PATH 只留 System32」真起一次桥来证明
  （Windows 没有 RPATH，缺 dll 的现象是 `0xC0000135`，屏幕上连一行字都没有）。
- 厂商库对 GM/T 0016 的偏离是实打实的，不是理论风险。已实测到的两例：中安云科的 PIN 编号是 **0 基**
  （`ADMIN_TYPE=0`/`USER_TYPE=1`，我们头文件的 `ADMIN_PIN=2` 传过去直接 `SAR_USER_TYPE_INVALID`；
  现在 `UkeyManager::adminPinSupported()` 会用**只读**的 `GetPINInfo` 探一次并按应用句柄缓存，
  结果三态 认/明确不认/未知 —— 只有"明确不认"才把界面上的解锁与"管理员 PIN"操作**置灰**并在
  tooltip、状态行写清原因，CLI 与服务端对管理员路径回同样的可读错误；未知时不动界面，避免把
  "没探到"当成"不支持"把按钮锁死。这类库的管理操作本就该走 §8.2.3 设备鉴权密钥），
  以及它的 `SKF_ExportCertificate` **给 PEM 不给 DER**（`UkeyManager::exportCert` 出口已统一剥壳）。
  接第 22 家之前先跑探针（§5.1）+ 静态取证（§5.2），别把结论留给猜。
- **`vendor_reimpl/` 的壳是 ABI 层复刻，不是等价实现**（§5.4）。标准入口靠后端转发，所以"壳能不能干活"
  完全取决于 `UK_REIMPL_BACKEND` 指向什么；后端缺席时一律 `0x0A000001`，不会假装成功。
  对拍覆盖到的也只是**无 PIN 只读链**：zayk 那 18 个手写扩展的判空次序与返回码来自反编译取证
  （[`third_party/decomp_findings.md`](third_party/decomp_findings.md)），**运行时没有和原厂比过** ——
  因为其中一批（`SKF_Login`、两个 `GenMaster*_SM9`）一进门就走 PIN/设备路径，拿 NULL 去调原厂库
  就不是只读操作，会消耗真机重试次数。另外三家没有钥匙插在这台机器上，对拍对齐的是
  加载 + 78 项符号 + 扩展清单这一段，设备链是 SKIP。真接进上层前，按 §5.1 的 PIN 规则单独把它们跑通。

## 8. 更多文档

- [`docs/调研-通用Ukey形态与实现.md`](docs/调研-通用Ukey形态与实现.md) —— **开发前置调研**：通用 Ukey 的形态与三套接口（SKF/CSP/PKCS#11）、GM/T 0016 模型与 2012/2023 版本现状、跨厂商差异警告、服务接入形态演进（ActiveX → 本地服务 + JS SDK）、GmSSL 双向支持 SKF 的机制与实测记录
- [`docs/设计与架构.md`](docs/设计与架构.md) —— 分层、软 Ukey 存储格式、SKF 句柄生命周期、后端切换
- [`docs/服务与SDK.md`](docs/服务与SDK.md) —— UKSEC-1 协议全文（报文/字段/公式）与 SDK 使用
- [`docs/接口与服务参考.md`](docs/接口与服务参考.md) —— 逐条源码核对的接口手册：SKF 覆盖表、SAR 码、`UkeyManager` API、`ukeyctl` 命令、HTTP 端点与 31 个 op
- [`docs/GMT 0016-2012 …接口规范.md`](docs/GMT%200016-2012%20智能密码钥匙密码应用接口规范.md) / [`docs/GMT 0017-2012 …数据格式规范.md`](docs/GMT%200017-2012%20智能密码钥匙密码应用接口数据格式规范.md) —— 标准原文
- [`sdk/python/README.md`](sdk/python/README.md) / [`sdk/js/README.md`](sdk/js/README.md) —— 两套 SDK 的细节与坑

## 9. flk UKey 助手通道 (/skf/oper)

`ukeyserv` 现在**同时服务三条通道**，驱动的是同一把 Ukey（同一个 `UkeyManager` 进程单例）：

| 通道 | 端口 | 协议 | 面向 |
| --- | --- | --- | --- |
| 安全通道 | 18080 (`[service]`) | UKSEC-1（SM2 协商 + SM4-CBC + HMAC-SM3 封套） | 本工程 SDK（ukeyctl / Python / Node / GUI） |
| flk 助手通道 | 61232 (`[flk]`) | flk 线协议：参数按字母序 → HMAC-SM3 → SM4-CBC（全零 IV、补零、无 PKCS#7）→ base64 | 中安云科 UKey 助手及其前端 SDK |
| 文档站 | 8555 (`[site]`) | 纯 HTTP 静态站点（复刻 `UkeySite/lib/serverCore.js`） | 浏览器：接入文档 + demo 页 |

flk 通道的实现：`src/sec/FlkProto.{h,cpp}`（线协议，密钥/IV 为原站 bundle 硬编码常量，改动即断互通）
与 `src/service/FlkBroker.{h,cpp}`（19 个 type 处理器：HasUkey / Login / ChangePIN / WriteData /
ECCSign / GenerateAuthData(ForP7GM) / ExportCert / ImportCert / GetEnvData …），
语义逐条对齐隔壁复刻站 `UkeyService/lib/ops.js`。

端口选择说明：中安云科 UKey 助手（及复刻站）用 **61231**，本服务默认 **61232** ——
同 URL 形态（`http://127.0.0.1:<port>/skf/oper`）但错开一位，本机同时跑两套（复刻站 + ukeyserv）
不冲突；联调真助手时把 `[flk] port` 或 `--flk-port` 改掉即可。

`config/ukey.ini` 的 `[flk]` 段控制该通道：

```ini
[flk]
enabled=true                 # false = 不挂这条通道
host=127.0.0.1
port=61232                   # 0 = 关闭
path=/skf/oper
hmac_key=01f845676601010155ab010101cd0101   # 原站常量, 勿改
sm4_key=3F54A1DC910C93CCB72438EDFF8CA630    # 原站常量, 勿改
sm4_iv=00000000000000000000000000000000     # 原站常量(全零 IV), 勿改
```

命令行覆盖：`ukeyserv --flk-port 61232 --flk-host 127.0.0.1`（`--flk-port 0` 关闭）。

### 9.1 文档站通道（8555，`[site]`）

第三条通道把隔壁 `../UkeySite` 的静态文档站直接挂进本进程（实现见
`src/service/SiteServer.{h,cpp}`，逐条复刻 `UkeySite/lib/serverCore.js` 的 `serveSite`），
这样用户只需 `ukeyserv` 或 `UkeyGui` **一个进程**就能同时拉起安全通道 / flk /skf/oper /
文档站三个端口，不必再单开一个 `node server.js`。

路由（只认 GET，其余 405）：

- `GET /` 与任意前端路由（`/api/xxx`、`/guide/xxx` …）→ `site/index.html`（SPA 回落）
- `GET /<静态资源>` → 命中 `site/` 下真实文件则按 MIME 发出
- `GET /docs/**.md` → 发 `docs/` 下的 markdown 原文（禁止 `..`，绝不越出 rootDir）
- `GET /provider.js` → 注入 `window.UKEY_PROVIDER`（"ukey 提供地址" + SDK 版本）
- `GET /health` → `{"ok":true,"provider":"…"}`

`config/ukey.ini` 的 `[site]` 段：

```ini
[site]
enabled=true
host=127.0.0.1
port=8555                      # 与 UkeySite/config/service.json 对齐; 0 = 关闭
root=../UkeySite               # 留空则自动探测 exeDir()/../UkeySite 等
provider_url=http://127.0.0.1:61232/skf/oper   # 打进 /provider.js 的"ukey 提供地址"
```

命令行覆盖：`ukeyserv --site-port 8555 --site-host 127.0.0.1 --site-root ../UkeySite`；
关闭整条通道用 `--no-site`（或 `[site] enabled=false` / `port=0`）。文档站是**尽力而为**：
端口被占或找不到 `UkeySite` 目录只告警跳过，不影响安全通道与 flk 通道。

每个接口文档页底部的「试调用」面板**只填字段，不填 JSON**：入参按 `FlkBroker::op*` 的口径列成表单
（必填项打 `*`，证书/信封这类长值给多行框，签名/加密槽给下拉），前端 `collectParams` 现场拼出参数，
旁边实时显示"拼出来的参数 JSON"供核对；必填没填会先指出是哪个字段，不发请求。可选项留空则**不进 JSON**，
与服务端的缺省口径对齐（例如 `ExportCert` 不给 `isSign` 就当签名证书）。

文档页 `##### 代码演示` 下的 ```tsx / ```jsx 示例由 `UkeySite/site/app.js` **现场编译成可交互表单**
（原站是 dumi 干这件事，本站零构建所以自己当那层编译器）：`@flk/Ukey` 的导入换成 `window.flkUkey`，
antd 的 `<Form.Item>` 换成等价控件，提交按示例自己的 `await a(); await b(x)` 顺序与实参打
`/skf/oper`，成功后照示例的 `form.setFieldsValue(...)` 回填，`message.success` 的模板串在点击时求值。
必填标记复用上面 `FIELDS` 的口径（`REQ_WIRE`），示例引用了但表单没给的字段自动补一个输入框。
**示例正文一个字没改**，解析不动的块（自定义 hook、指南里的 ```js 片段）原样退回纯代码。
