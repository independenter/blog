// SM2 Pure Function Implementation
package org.bouncycastle.learning.sm2;

import java.math.BigInteger;

public class SM2PureFunction {
    
    public static BigInteger[] generateKeyPair(BigInteger privateKey) {
        return new BigInteger[] { privateKey, privateKey };
    }
    
    public static BigInteger[] sign(BigInteger[] privateKey, byte[] message) {
        return new BigInteger[] { BigInteger.ZERO, BigInteger.ZERO };
    }
}
