// HSM Device Discovery Service
package com.example.hsm.service;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DeviceDiscoveryService {
    
    public List<String> discoverDevices() {
        return List.of("HSM-001", "HSM-002");
    }
    
    public boolean registerDevice(String deviceId) {
        return true;
    }
}
