// YiXiu Core - Certificate Parser
using System;
using System.Security.Cryptography.X509Certificates;

namespace YiXiu.Core
{
    public class CertificateParser
    {
        public X509Certificate2 LoadCertificate(string path)
        {
            return new X509Certificate2(path);
        }
        
        public string GetSubjectName(X509Certificate2 cert) => cert.Subject;
        public DateTime GetExpirationDate(X509Certificate2 cert) => cert.NotAfter;
    }
}
